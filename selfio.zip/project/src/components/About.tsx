import React from 'react';
import { GraduationCap, Target, Zap } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">About Me</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A passionate developer with a love for creating meaningful solutions and exploring the endless possibilities of technology.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Side - Image/Visual */}
          <div className="relative">
            <div className="aspect-square bg-gradient-to-br from-blue-900/50 to-purple-900/50 rounded-2xl p-8 flex items-center justify-center border border-gray-700">
              <div className="text-center">
                <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                  <GraduationCap className="h-12 w-12 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Student Developer</h3>
                <p className="text-gray-300">Learning, Building, Growing</p>
              </div>
            </div>
          </div>

          {/* Right Side - Content */}
          <div className="space-y-8">
            <div className="prose prose-lg">
              <p className="text-gray-300 leading-relaxed">
                I'm Mahima Rani, a dedicated second-year student at Noida Institute of Engineering and Technology. 
                My journey in technology is driven by curiosity and a genuine passion for problem-solving.
              </p>
              <p className="text-gray-300 leading-relaxed">
                When I'm not coding, you can find me exploring nature, reading books, or playing badminton. 
                I believe in maintaining a balance between technical skills and personal interests.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-blue-900/30 rounded-lg p-6 border border-blue-700/30">
                <Target className="h-8 w-8 text-blue-400 mb-3" />
                <h4 className="font-semibold text-white mb-2">My Strengths</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• Hardworking & Disciplined</li>
                  <li>• Technology Explorer</li>
                  <li>• Problem Solver</li>
                </ul>
              </div>

              <div className="bg-purple-900/30 rounded-lg p-6 border border-purple-700/30">
                <Zap className="h-8 w-8 text-purple-400 mb-3" />
                <h4 className="font-semibold text-white mb-2">Current Focus</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• Full-Stack Development</li>
                  <li>• Modern Web Technologies</li>
                  <li>• Open Source Contribution</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;