import React from 'react';
import { Code, Palette } from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: 'Programming Languages',
      icon: <Code className="h-8 w-8" />,
      skills: [
        { name: 'JavaScript', level: 85, color: 'bg-yellow-500' },
        { name: 'Python', level: 75, color: 'bg-blue-500' },
        { name: 'Java', level: 70, color: 'bg-red-500' },
        { name: 'C', level: 80, color: 'bg-green-500' },
      ],
    },
    {
      title: 'Web Technologies',
      icon: <Palette className="h-8 w-8" />,
      skills: [
        { name: 'HTML/CSS', level: 90, color: 'bg-orange-500' },
        { name: 'React', level: 75, color: 'bg-blue-400' },
        { name: 'Tailwind CSS', level: 80, color: 'bg-teal-500' },
        { name: 'Node.js', level: 65, color: 'bg-green-600' },
      ],
    },
  ];

  return (
    <section id="skills" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Skills & Technologies</h2>
          <p className="text-xl text-gray-300">
            Constantly learning and improving my technical expertise
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-gray-800 rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300 border border-gray-700">
              <div className="flex items-center mb-6">
                <div className="bg-blue-900/50 rounded-lg p-3 mr-4 border border-blue-700/30">
                  {category.icon}
                </div>
                <h3 className="text-2xl font-bold text-white">{category.title}</h3>
              </div>

              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="skill-item">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-300 font-medium">{skill.name}</span>
                      <span className="text-gray-400 text-sm">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${skill.color} skill-progress`}
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;