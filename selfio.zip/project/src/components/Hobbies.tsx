import React from 'react';
import { BookOpen, Zap, Trees, Heart } from 'lucide-react';

const Hobbies = () => {
  const hobbies = [
    {
      title: 'Reading Books',
      description: 'Exploring different worlds through literature, from tech blogs to fiction novels.',
      icon: <BookOpen className="h-8 w-8" />,
      color: 'from-purple-500 to-pink-500',
      bgColor: 'bg-purple-900/30',
      borderColor: 'border-purple-700/30',
    },
    {
      title: 'Playing Badminton',
      description: 'Staying active and competitive through this fast-paced sport.',
      icon: <Zap className="h-8 w-8" />,
      color: 'from-green-500 to-blue-500',
      bgColor: 'bg-green-900/30',
      borderColor: 'border-green-700/30',
    },
    {
      title: 'Exploring Nature',
      description: 'Finding inspiration and peace in the great outdoors.',
      icon: <Trees className="h-8 w-8" />,
      color: 'from-green-500 to-teal-500',
      bgColor: 'bg-teal-900/30',
      borderColor: 'border-teal-700/30',
    },
  ];

  return (
    <section id="hobbies" className="py-20 bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Beyond Coding</h2>
          <p className="text-xl text-gray-300">
            What keeps me balanced and inspired outside of technology
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {hobbies.map((hobby, index) => (
            <div key={index} className={`hobby-card bg-gray-800 rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition-all duration-300 border ${hobby.borderColor}`}>
              <div className={`w-16 h-16 mx-auto mb-6 rounded-full bg-gradient-to-r ${hobby.color} flex items-center justify-center text-white`}>
                {hobby.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{hobby.title}</h3>
              <p className="text-gray-300 leading-relaxed">{hobby.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-pink-500 to-red-500 rounded-full mb-6">
            <Heart className="h-8 w-8 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">Life Philosophy</h3>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto leading-relaxed">
            I believe in maintaining a healthy balance between professional growth and personal well-being. 
            Each hobby teaches me something new that I can apply to my coding journey.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Hobbies;