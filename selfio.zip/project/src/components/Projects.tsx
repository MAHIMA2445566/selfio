import React from 'react';
import { ExternalLink, Github } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'MovieEve',
      description: 'A modern movie discovery platform with advanced search and filtering capabilities. Built with React and external APIs for seamless movie browsing experience.',
      technologies: ['React', 'JavaScript', 'CSS', 'API Integration'],
      image: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1200',
      githubLink: 'https://github.com/MAHIMA2445566/MoviEve',
      category: 'Web Application',
    },
    {
      title: 'Smart Calculator',
      description: 'An advanced calculator with scientific functions, history tracking, and beautiful UI design for enhanced mathematical computations.',
      technologies: ['JavaScript', 'HTML', 'CSS', 'Local Storage'],
      image: 'https://images.pexels.com/photos/6335/man-coffee-cup-pen.jpg?auto=compress&cs=tinysrgb&w=1200',
      githubLink: 'https://github.com/MAHIMA2445566/calculator',
      category: 'Utility App',
    },
    {
      title: 'Todo App',
      description: 'A feature-rich todo application with categories, priorities, and progress tracking built with Python for efficient task management.',
      technologies: ['Python', 'Tkinter', 'File Handling'],
      image: 'https://images.pexels.com/photos/1226398/pexels-photo-1226398.jpeg?auto=compress&cs=tinysrgb&w=1200',
      githubLink: 'https://github.com/MAHIMA2445566/to-do-list.py',
      category: 'Productivity',
    },
    {
      title: 'Rock Paper Scissors Game',
      description: 'An interactive Rock Paper Scissors game with engaging UI and score tracking for endless entertainment.',
      technologies: ['Python', 'Random Module', 'Game Logic'],
      image: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=1200',
      githubLink: 'https://github.com/MAHIMA2445566/rock-paper-sessior-game',
      category: 'Game',
    },
    {
      title: 'Quiz Game',
      description: 'An educational quiz application with multiple categories and difficulty levels to test knowledge across various subjects.',
      technologies: ['Python', 'JSON', 'File I/O'],
      image: 'https://images.pexels.com/photos/5428010/pexels-photo-5428010.jpeg?auto=compress&cs=tinysrgb&w=1200',
      githubLink: 'https://github.com/MAHIMA2445566/QUIZ_game.py',
      category: 'Educational',
    },
    {
      title: 'Password Generator',
      description: 'A secure password generator with customizable length and character sets to create strong, unique passwords for enhanced security.',
      technologies: ['Python', 'Random Module', 'String Operations'],
      image: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=1200',
      githubLink: 'https://github.com/MAHIMA2445566/password-generator',
      category: 'Security Tool',
    },
  ];

  return (
    <section id="projects" className="py-20 bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Featured Projects</h2>
          <p className="text-xl text-gray-300">
            A showcase of my recent work and technical achievements
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="project-card bg-gray-900 rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 border border-gray-700">
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover transform hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.category}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                <p className="text-gray-300 mb-4 leading-relaxed">{project.description}</p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm border border-gray-600"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex space-x-3">
                    <a
                      href={project.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center text-gray-300 hover:text-white transition-colors duration-200"
                    >
                      <Github className="h-4 w-4 mr-1" />
                      Code
                    </a>
                  </div>
                  <a
                    href={project.githubLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 hover:text-blue-300 transition-colors duration-200"
                  >
                    <ExternalLink className="h-5 w-5" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;